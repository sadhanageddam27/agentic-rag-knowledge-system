"""
rag_pipeline.py — Core Agentic RAG Pipeline

Architecture:
    Documents → Chunker → Embedder → VectorStore
    Query → Embedder → Retriever → LLM → Answer

Supports:
    - Multiple document formats (PDF, TXT, MD)
    - Semantic chunking with overlap
    - ChromaDB vector store
    - OpenAI / Ollama LLM backends
    - Agentic multi-step reasoning loop
"""

import os
import time
import logging
from pathlib import Path
from typing import List, Dict, Optional, Any
from dataclasses import dataclass, field

from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger(__name__)


# ── Data Models ────────────────────────────────────────────────────────────────

@dataclass
class Document:
    """Represents a source document or chunk."""
    content: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    doc_id: str = ""

    def __post_init__(self):
        if not self.doc_id:
            import hashlib
            self.doc_id = hashlib.md5(self.content.encode()).hexdigest()[:12]


@dataclass
class RetrievedChunk:
    """A document chunk returned from vector search."""
    content: str
    metadata: Dict[str, Any]
    score: float
    doc_id: str


@dataclass
class RAGResponse:
    """Final response from the RAG pipeline."""
    answer: str
    sources: List[RetrievedChunk]
    query: str
    reasoning_steps: List[str] = field(default_factory=list)
    latency_ms: float = 0.0


# ── Document Loader ────────────────────────────────────────────────────────────

class DocumentLoader:
    """
    Loads documents from files or raw text.
    Supports: .txt, .md, .pdf (via pdfplumber)
    """

    def load_file(self, path: str) -> Document:
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")

        suffix = path.suffix.lower()
        if suffix in (".txt", ".md"):
            content = path.read_text(encoding="utf-8")
        elif suffix == ".pdf":
            content = self._load_pdf(path)
        else:
            raise ValueError(f"Unsupported file type: {suffix}")

        return Document(
            content=content,
            metadata={"source": str(path), "filename": path.name}
        )

    def load_text(self, text: str, source: str = "direct_input") -> Document:
        return Document(
            content=text,
            metadata={"source": source}
        )

    def load_directory(self, dir_path: str) -> List[Document]:
        docs = []
        for p in Path(dir_path).rglob("*"):
            if p.suffix.lower() in (".txt", ".md", ".pdf"):
                try:
                    docs.append(self.load_file(str(p)))
                    logger.info(f"Loaded: {p.name}")
                except Exception as e:
                    logger.warning(f"Skipped {p.name}: {e}")
        return docs

    def _load_pdf(self, path: Path) -> str:
        try:
            import pdfplumber
            text = []
            with pdfplumber.open(str(path)) as pdf:
                for page in pdf.pages:
                    t = page.extract_text()
                    if t:
                        text.append(t)
            return "\n".join(text)
        except ImportError:
            raise ImportError("Install pdfplumber: pip install pdfplumber")


# ── Text Chunker ───────────────────────────────────────────────────────────────

class TextChunker:
    """
    Splits documents into overlapping chunks for better retrieval.

    chunk_size:    target tokens per chunk (approx 4 chars = 1 token)
    overlap:       tokens shared between consecutive chunks
    """

    def __init__(self, chunk_size: int = 512, overlap: int = 64):
        self.chunk_size = chunk_size
        self.overlap = overlap

    def chunk_document(self, doc: Document) -> List[Document]:
        text = doc.content
        chunks = self._split_text(text)
        result = []
        for i, chunk in enumerate(chunks):
            metadata = {**doc.metadata, "chunk_index": i, "total_chunks": len(chunks)}
            result.append(Document(content=chunk, metadata=metadata))
        return result

    def chunk_documents(self, docs: List[Document]) -> List[Document]:
        all_chunks = []
        for doc in docs:
            all_chunks.extend(self.chunk_document(doc))
        logger.info(f"Chunked {len(docs)} documents → {len(all_chunks)} chunks")
        return all_chunks

    def _split_text(self, text: str) -> List[str]:
        """Split by paragraphs first, then by character limit."""
        # Try paragraph-aware splitting
        paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
        chunks = []
        current = []
        current_len = 0

        # ~4 chars per token
        max_chars = self.chunk_size * 4
        overlap_chars = self.overlap * 4

        for para in paragraphs:
            para_len = len(para)
            if current_len + para_len > max_chars and current:
                chunk_text = "\n\n".join(current)
                chunks.append(chunk_text)
                # Keep overlap: last paragraph(s) that fit in overlap window
                overlap_text = []
                overlap_used = 0
                for p in reversed(current):
                    if overlap_used + len(p) <= overlap_chars:
                        overlap_text.insert(0, p)
                        overlap_used += len(p)
                    else:
                        break
                current = overlap_text
                current_len = sum(len(p) for p in current)
            current.append(para)
            current_len += para_len

        if current:
            chunks.append("\n\n".join(current))

        return chunks if chunks else [text]


# ── Embedder ───────────────────────────────────────────────────────────────────

class Embedder:
    """
    Generates vector embeddings for text chunks.

    Backend options:
        "openai"   — text-embedding-ada-002 (requires OPENAI_API_KEY)
        "local"    — sentence-transformers/all-MiniLM-L6-v2 (free, offline)
    """

    def __init__(self, backend: str = "local", model: str = None):
        self.backend = backend
        self.model_name = model
        self._model = None
        self._client = None

    def _load_model(self):
        if self._model is not None or self._client is not None:
            return

        if self.backend == "openai":
            from openai import OpenAI
            self._client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
            self.model_name = self.model_name or "text-embedding-ada-002"
            logger.info(f"Embedder: OpenAI ({self.model_name})")

        elif self.backend == "local":
            from sentence_transformers import SentenceTransformer
            self.model_name = self.model_name or "all-MiniLM-L6-v2"
            self._model = SentenceTransformer(self.model_name)
            logger.info(f"Embedder: local ({self.model_name})")

        else:
            raise ValueError(f"Unknown embedder backend: {self.backend}")

    def embed(self, texts: List[str]) -> List[List[float]]:
        self._load_model()

        if self.backend == "openai":
            response = self._client.embeddings.create(
                model=self.model_name,
                input=texts
            )
            return [item.embedding for item in response.data]

        elif self.backend == "local":
            embeddings = self._model.encode(texts, show_progress_bar=False)
            return embeddings.tolist()

    def embed_one(self, text: str) -> List[float]:
        return self.embed([text])[0]

    @property
    def dimension(self) -> int:
        dims = {"text-embedding-ada-002": 1536, "all-MiniLM-L6-v2": 384}
        return dims.get(self.model_name, 384)


# ── Vector Store ───────────────────────────────────────────────────────────────

class VectorStore:
    """
    ChromaDB-backed vector store for semantic similarity search.

    Stores document chunks with their embeddings and metadata.
    Supports add, search, and delete operations.
    """

    def __init__(
        self,
        collection_name: str = "rag_docs",
        persist_dir: str = "./chroma_db",
        embedder: Optional[Embedder] = None
    ):
        self.collection_name = collection_name
        self.persist_dir = persist_dir
        self.embedder = embedder or Embedder(backend="local")
        self._collection = None

    def _get_collection(self):
        if self._collection is not None:
            return self._collection

        import chromadb
        client = chromadb.PersistentClient(path=self.persist_dir)
        self._collection = client.get_or_create_collection(
            name=self.collection_name,
            metadata={"hnsw:space": "cosine"}
        )
        logger.info(f"VectorStore: collection '{self.collection_name}' "
                    f"({self._collection.count()} docs)")
        return self._collection

    def add_documents(self, docs: List[Document]) -> None:
        """Embed and store documents in the vector store."""
        if not docs:
            return

        collection = self._get_collection()
        texts = [d.content for d in docs]
        embeddings = self.embedder.embed(texts)

        collection.add(
            ids=[d.doc_id for d in docs],
            embeddings=embeddings,
            documents=texts,
            metadatas=[d.metadata for d in docs]
        )
        logger.info(f"Added {len(docs)} chunks to vector store")

    def search(
        self,
        query: str,
        top_k: int = 5,
        score_threshold: float = 0.0
    ) -> List[RetrievedChunk]:
        """Semantic search — returns top_k most relevant chunks."""
        collection = self._get_collection()
        query_embedding = self.embedder.embed_one(query)

        results = collection.query(
            query_embeddings=[query_embedding],
            n_results=min(top_k, collection.count()),
            include=["documents", "metadatas", "distances"]
        )

        chunks = []
        for doc, meta, dist in zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0]
        ):
            # ChromaDB cosine distance → similarity score
            score = 1.0 - dist
            if score >= score_threshold:
                chunks.append(RetrievedChunk(
                    content=doc,
                    metadata=meta,
                    score=round(score, 4),
                    doc_id=meta.get("doc_id", "")
                ))

        logger.info(f"Retrieved {len(chunks)} chunks for query: '{query[:60]}...'")
        return chunks

    def count(self) -> int:
        return self._get_collection().count()

    def clear(self) -> None:
        import chromadb
        client = chromadb.PersistentClient(path=self.persist_dir)
        client.delete_collection(self.collection_name)
        self._collection = None
        logger.info(f"Cleared collection '{self.collection_name}'")


# ── LLM Client ────────────────────────────────────────────────────────────────

class LLMClient:
    """
    OpenAI-compatible LLM wrapper.
    Works with: OpenAI API, Ollama, any OpenAI-compatible endpoint.
    """

    def __init__(
        self,
        backend: str = "openai",
        model: str = None,
        base_url: str = None,
        temperature: float = 0.2,
        max_tokens: int = 1024
    ):
        self.backend = backend
        self.temperature = temperature
        self.max_tokens = max_tokens
        self._client = None

        if backend == "openai":
            self.model = model or "gpt-3.5-turbo"
            self.base_url = base_url or "https://api.openai.com/v1"
        elif backend == "ollama":
            self.model = model or "llama3"
            self.base_url = base_url or "http://localhost:11434/v1"
        else:
            raise ValueError(f"Unknown LLM backend: {backend}")

    def _get_client(self):
        if self._client is None:
            from openai import OpenAI
            self._client = OpenAI(
                api_key=os.environ.get("OPENAI_API_KEY", "ollama"),
                base_url=self.base_url
            )
        return self._client

    def complete(self, system: str, user: str) -> str:
        client = self._get_client()
        response = client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user}
            ],
            temperature=self.temperature,
            max_tokens=self.max_tokens
        )
        return response.choices[0].message.content.strip()


# ── RAG Pipeline ──────────────────────────────────────────────────────────────

class RAGPipeline:
    """
    Core Retrieval-Augmented Generation pipeline.

    Usage:
        pipeline = RAGPipeline()
        pipeline.ingest_directory("./my_docs")
        response = pipeline.query("What is the refund policy?")
        print(response.answer)
    """

    SYSTEM_PROMPT = """You are a knowledgeable assistant that answers questions
based strictly on the provided context documents.

Rules:
- Answer only from the provided context
- If the context does not contain the answer, say "I don't have enough information in the provided documents to answer this question."
- Be concise and precise
- Cite the source document when relevant
- Do not hallucinate or add information not in the context"""

    def __init__(
        self,
        embedder: Optional[Embedder] = None,
        vector_store: Optional[VectorStore] = None,
        llm: Optional[LLMClient] = None,
        chunk_size: int = 512,
        chunk_overlap: int = 64,
        top_k: int = 5,
        score_threshold: float = 0.3
    ):
        self.embedder = embedder or Embedder(backend="local")
        self.vector_store = vector_store or VectorStore(embedder=self.embedder)
        self.llm = llm or LLMClient(backend="openai")
        self.chunker = TextChunker(chunk_size=chunk_size, overlap=chunk_overlap)
        self.loader = DocumentLoader()
        self.top_k = top_k
        self.score_threshold = score_threshold

    def ingest(self, docs: List[Document]) -> int:
        """Chunk and index documents into the vector store."""
        chunks = self.chunker.chunk_documents(docs)
        self.vector_store.add_documents(chunks)
        return len(chunks)

    def ingest_text(self, text: str, source: str = "direct") -> int:
        doc = self.loader.load_text(text, source)
        return self.ingest([doc])

    def ingest_file(self, path: str) -> int:
        doc = self.loader.load_file(path)
        return self.ingest([doc])

    def ingest_directory(self, dir_path: str) -> int:
        docs = self.loader.load_directory(dir_path)
        return self.ingest(docs)

    def query(self, question: str) -> RAGResponse:
        """
        Full RAG query:
        1. Retrieve relevant chunks
        2. Build context-augmented prompt
        3. Generate grounded answer
        """
        start = time.time()

        # Step 1: Retrieve
        chunks = self.vector_store.search(
            query=question,
            top_k=self.top_k,
            score_threshold=self.score_threshold
        )

        if not chunks:
            return RAGResponse(
                answer="I don't have enough information in the provided documents to answer this question.",
                sources=[],
                query=question,
                reasoning_steps=["No relevant documents found above threshold"],
                latency_ms=round((time.time() - start) * 1000, 1)
            )

        # Step 2: Build prompt
        context = self._build_context(chunks)
        user_prompt = f"Context:\n{context}\n\nQuestion: {question}"

        # Step 3: Generate
        answer = self.llm.complete(
            system=self.SYSTEM_PROMPT,
            user=user_prompt
        )

        latency = round((time.time() - start) * 1000, 1)
        logger.info(f"Query answered in {latency}ms")

        return RAGResponse(
            answer=answer,
            sources=chunks,
            query=question,
            reasoning_steps=[
                f"Retrieved {len(chunks)} relevant chunks",
                f"Top chunk score: {chunks[0].score}",
                f"Generated answer using {self.llm.model}"
            ],
            latency_ms=latency
        )

    def _build_context(self, chunks: List[RetrievedChunk]) -> str:
        parts = []
        for i, chunk in enumerate(chunks, 1):
            source = chunk.metadata.get("filename", chunk.metadata.get("source", "unknown"))
            parts.append(f"[Document {i} | Source: {source} | Score: {chunk.score}]\n{chunk.content}")
        return "\n\n---\n\n".join(parts)
