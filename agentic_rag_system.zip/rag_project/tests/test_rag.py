"""
tests/test_rag.py — Unit tests for RAG components

Run: pytest tests/ -v
"""

import pytest
from unittest.mock import MagicMock, patch
from src.rag_pipeline import (
    Document, TextChunker, DocumentLoader,
    RetrievedChunk, RAGPipeline
)
from src.agentic_rag import AgenticRAG


# ── TextChunker Tests ─────────────────────────────────────────────────────────

class TestTextChunker:

    def test_short_text_stays_single_chunk(self):
        chunker = TextChunker(chunk_size=512, overlap=64)
        doc = Document(content="Short text that fits in one chunk.")
        chunks = chunker.chunk_document(doc)
        assert len(chunks) == 1
        assert chunks[0].content == "Short text that fits in one chunk."

    def test_long_text_splits_into_multiple_chunks(self):
        chunker = TextChunker(chunk_size=50, overlap=10)
        # Create text with clear paragraph breaks
        paragraphs = [f"Paragraph {i}. " + "Word " * 30 for i in range(10)]
        content = "\n\n".join(paragraphs)
        doc = Document(content=content)
        chunks = chunker.chunk_document(doc)
        assert len(chunks) > 1

    def test_chunk_metadata_has_indices(self):
        chunker = TextChunker(chunk_size=50, overlap=5)
        paragraphs = [f"Paragraph {i}. " + "Word " * 30 for i in range(6)]
        doc = Document(content="\n\n".join(paragraphs), metadata={"source": "test.txt"})
        chunks = chunker.chunk_document(doc)
        for i, chunk in enumerate(chunks):
            assert "chunk_index" in chunk.metadata
            assert "total_chunks" in chunk.metadata
            assert chunk.metadata["source"] == "test.txt"

    def test_chunk_preserves_source_metadata(self):
        chunker = TextChunker()
        doc = Document(content="Some text.", metadata={"filename": "doc.txt", "author": "test"})
        chunks = chunker.chunk_document(doc)
        assert chunks[0].metadata["filename"] == "doc.txt"
        assert chunks[0].metadata["author"] == "test"


# ── DocumentLoader Tests ──────────────────────────────────────────────────────

class TestDocumentLoader:

    def test_load_text(self):
        loader = DocumentLoader()
        doc = loader.load_text("Hello world", source="test")
        assert doc.content == "Hello world"
        assert doc.metadata["source"] == "test"

    def test_load_txt_file(self, tmp_path):
        loader = DocumentLoader()
        f = tmp_path / "test.txt"
        f.write_text("File content here")
        doc = loader.load_file(str(f))
        assert doc.content == "File content here"
        assert doc.metadata["filename"] == "test.txt"

    def test_load_md_file(self, tmp_path):
        loader = DocumentLoader()
        f = tmp_path / "readme.md"
        f.write_text("# Title\n\nContent here")
        doc = loader.load_file(str(f))
        assert "Title" in doc.content

    def test_unsupported_format_raises(self, tmp_path):
        loader = DocumentLoader()
        f = tmp_path / "data.csv"
        f.write_text("col1,col2")
        with pytest.raises(ValueError, match="Unsupported"):
            loader.load_file(str(f))

    def test_missing_file_raises(self):
        loader = DocumentLoader()
        with pytest.raises(FileNotFoundError):
            loader.load_file("/nonexistent/path/file.txt")

    def test_load_directory(self, tmp_path):
        loader = DocumentLoader()
        (tmp_path / "a.txt").write_text("Document A")
        (tmp_path / "b.txt").write_text("Document B")
        (tmp_path / "skip.csv").write_text("ignored")
        docs = loader.load_directory(str(tmp_path))
        assert len(docs) == 2
        contents = {d.content for d in docs}
        assert "Document A" in contents
        assert "Document B" in contents


# ── Document Tests ────────────────────────────────────────────────────────────

class TestDocument:

    def test_auto_generates_doc_id(self):
        doc = Document(content="test content")
        assert doc.doc_id != ""
        assert len(doc.doc_id) == 12

    def test_same_content_same_id(self):
        doc1 = Document(content="identical")
        doc2 = Document(content="identical")
        assert doc1.doc_id == doc2.doc_id

    def test_different_content_different_id(self):
        doc1 = Document(content="content A")
        doc2 = Document(content="content B")
        assert doc1.doc_id != doc2.doc_id


# ── RAG Pipeline Tests (mocked) ───────────────────────────────────────────────

class TestRAGPipeline:

    def _make_mock_pipeline(self):
        """Create a RAGPipeline with all external deps mocked."""
        mock_embedder = MagicMock()
        mock_embedder.embed.return_value = [[0.1, 0.2, 0.3]]
        mock_embedder.embed_one.return_value = [0.1, 0.2, 0.3]

        mock_vector_store = MagicMock()
        mock_vector_store.count.return_value = 5
        mock_vector_store.search.return_value = [
            RetrievedChunk(
                content="The return window is 30 days.",
                metadata={"filename": "policy.txt", "chunk_index": 0},
                score=0.92,
                doc_id="abc123"
            )
        ]

        mock_llm = MagicMock()
        mock_llm.model = "gpt-3.5-turbo"
        mock_llm.complete.return_value = "You can return items within 30 days."

        pipeline = RAGPipeline(
            embedder=mock_embedder,
            vector_store=mock_vector_store,
            llm=mock_llm
        )
        return pipeline

    def test_query_returns_response(self):
        pipeline = self._make_mock_pipeline()
        response = pipeline.query("What is the return policy?")
        assert response.answer == "You can return items within 30 days."
        assert response.query == "What is the return policy?"
        assert len(response.sources) == 1
        assert response.latency_ms > 0

    def test_query_with_no_results_returns_fallback(self):
        pipeline = self._make_mock_pipeline()
        pipeline.vector_store.search.return_value = []
        response = pipeline.query("Unknown topic")
        assert "don't have enough information" in response.answer.lower()
        assert len(response.sources) == 0

    def test_ingest_text_calls_vector_store(self):
        pipeline = self._make_mock_pipeline()
        pipeline.embedder.embed.return_value = [[0.1] * 10]
        pipeline.vector_store.add_documents = MagicMock()
        pipeline.ingest_text("Some document content", source="test")
        pipeline.vector_store.add_documents.assert_called_once()

    def test_context_built_correctly(self):
        pipeline = self._make_mock_pipeline()
        chunks = [
            RetrievedChunk("Content A", {"filename": "a.txt"}, 0.9, "id1"),
            RetrievedChunk("Content B", {"filename": "b.txt"}, 0.7, "id2"),
        ]
        context = pipeline._build_context(chunks)
        assert "Document 1" in context
        assert "Document 2" in context
        assert "Content A" in context
        assert "Content B" in context
        assert "a.txt" in context


# ── Agentic RAG Tests (mocked) ────────────────────────────────────────────────

class TestAgenticRAG:

    def _make_mock_agent(self, is_complex=False):
        mock_pipeline = MagicMock()
        mock_pipeline.query.return_value = MagicMock(
            answer="Simple answer",
            sources=[RetrievedChunk("content", {"filename": "f.txt"}, 0.9, "id1")],
            query="test question",
            reasoning_steps=[],
            latency_ms=100.0
        )
        mock_pipeline.vector_store.search.return_value = [
            RetrievedChunk("evidence content", {"filename": "f.txt"}, 0.85, "id1")
        ]
        mock_pipeline.llm.complete.side_effect = [
            "complex" if is_complex else "simple",   # classify call
            '["sub-q 1", "sub-q 2"]',                # decompose call
            "Synthesized answer"                      # synthesize call
        ]
        return AgenticRAG(rag_pipeline=mock_pipeline)

    def test_simple_question_uses_standard_rag(self):
        agent = self._make_mock_agent(is_complex=False)
        response = agent.query("Simple question?")
        assert not response.is_complex
        agent.rag.query.assert_called_once()

    def test_complex_question_decomposes(self):
        agent = self._make_mock_agent(is_complex=True)
        response = agent.query("Complex multi-part question?")
        assert response.is_complex
        # Should have classify + decompose + retrieve + synthesize steps
        step_types = [s.step_type for s in response.steps]
        assert "classify" in step_types
        assert "decompose" in step_types

    def test_response_has_reasoning_trace(self):
        agent = self._make_mock_agent(is_complex=False)
        response = agent.query("What is the policy?")
        assert len(response.steps) > 0
        assert response.latency_ms > 0
